/**
 * 
 */
/**
 * 
 */
module CalculadoraOperativa {
}