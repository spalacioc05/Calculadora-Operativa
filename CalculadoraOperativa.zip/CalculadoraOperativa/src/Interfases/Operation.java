package Interfaces;

/**
 *
 * @author spala
 */

public interface Operation {
    void execute();

}